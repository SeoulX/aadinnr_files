#!/bin/bash

# Minikube Restore Script
# This script restores your minikube deployments from backup

set -e

BACKUP_DIR="/home/andrian/aadinnr_files/backups"
BACKUP_NAME=""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to check if minikube is running
check_minikube() {
    if ! minikube status >/dev/null 2>&1; then
        echo -e "${YELLOW}⚠️  Minikube is not running. Starting minikube...${NC}"
        minikube start
    else
        echo -e "${GREEN}✅ Minikube is running${NC}"
    fi
}

# Function to wait for namespace to be ready
wait_for_namespace() {
    local namespace=$1
    local timeout=30
    local count=0
    
    while [ $count -lt $timeout ]; do
        if kubectl get namespace "$namespace" >/dev/null 2>&1; then
            echo -e "${GREEN}✅ Namespace $namespace is ready${NC}"
            return 0
        fi
        sleep 1
        count=$((count + 1))
    done
    
    echo -e "${RED}❌ Timeout waiting for namespace $namespace${NC}"
    return 1
}

# Function to restore resources safely
restore_resource() {
    local file=$1
    local description=$2
    
    if [ -f "$file" ] && [ -s "$file" ]; then
        echo -e "${BLUE}📄 Restoring $description...${NC}"
        if kubectl apply -f "$file" 2>/dev/null; then
            echo -e "${GREEN}✅ $description restored successfully${NC}"
        else
            echo -e "${YELLOW}⚠️  Warning: Some $description resources may have conflicts${NC}"
        fi
    else
        echo -e "${YELLOW}⚠️  No $description file found or file is empty${NC}"
    fi
}

if [ -z "$1" ]; then
    echo -e "${RED}❌ Please provide backup name as argument${NC}"
    echo "Usage: $0 <backup_name>"
    echo "Available backups:"
    ls -la "${BACKUP_DIR}" | grep minikube_backup || echo "No backups found"
    exit 1
fi

BACKUP_NAME="$1"
FULL_BACKUP_PATH="${BACKUP_DIR}/${BACKUP_NAME}"

if [ ! -d "${FULL_BACKUP_PATH}" ]; then
    echo -e "${RED}❌ Backup directory not found: ${FULL_BACKUP_PATH}${NC}"
    echo "Available backups:"
    ls -la "${BACKUP_DIR}" | grep minikube_backup || echo "No backups found"
    exit 1
fi

echo -e "${GREEN}🔄 Starting Minikube Restore Process...${NC}"
echo "Backup: ${BACKUP_NAME}"
echo "Path: ${FULL_BACKUP_PATH}"

# Check and start minikube if needed
check_minikube

# Wait for minikube to be ready
echo -e "${YELLOW}⏳ Waiting for minikube to be ready...${NC}"
sleep 10

# Restore cluster-wide resources
echo -e "${YELLOW}🌐 Restoring cluster-wide resources...${NC}"
restore_resource "${FULL_BACKUP_PATH}/cluster/namespaces.yaml" "namespaces"
restore_resource "${FULL_BACKUP_PATH}/cluster/storageclass.yaml" "storage classes"
restore_resource "${FULL_BACKUP_PATH}/cluster/clusterroles.yaml" "cluster roles"
restore_resource "${FULL_BACKUP_PATH}/cluster/clusterrolebindings.yaml" "cluster role bindings"

# Wait for namespaces to be ready
sleep 5

# Restore namespaces
echo -e "${YELLOW}📦 Restoring namespace resources...${NC}"
for namespace_dir in "${FULL_BACKUP_PATH}/namespaces"/*; do
    if [ -d "${namespace_dir}" ]; then
        namespace=$(basename "${namespace_dir}")
        echo -e "${YELLOW}📦 Processing namespace: ${namespace}${NC}"
        
        # Create namespace if it doesn't exist
        if ! kubectl get namespace "$namespace" >/dev/null 2>&1; then
            echo -e "${BLUE}📝 Creating namespace: ${namespace}${NC}"
            kubectl create namespace "$namespace" || echo -e "${YELLOW}⚠️  Namespace ${namespace} may already exist${NC}"
        fi
        
        # Wait for namespace to be ready
        wait_for_namespace "$namespace"
        
        # Restore resources in order
        restore_resource "${namespace_dir}/configmaps.yaml" "configmaps for ${namespace}"
        restore_resource "${namespace_dir}/secrets.yaml" "secrets for ${namespace}"
        restore_resource "${namespace_dir}/pvc.yaml" "PVCs for ${namespace}"
        restore_resource "${namespace_dir}/pv.yaml" "PVs for ${namespace}"
        restore_resource "${namespace_dir}/all-resources.yaml" "other resources for ${namespace}"
        restore_resource "${namespace_dir}/ingress.yaml" "ingress for ${namespace}"
        
        echo -e "${GREEN}✅ Namespace ${namespace} restored${NC}"
    fi
done

# Restore Helm releases
echo -e "${YELLOW}📊 Restoring Helm releases...${NC}"
if [ -f "${FULL_BACKUP_PATH}/helm/releases.yaml" ]; then
    echo -e "${BLUE}📄 Found Helm releases backup${NC}"
    
    # Extract release information and restore
    while IFS= read -r line; do
        if echo "$line" | grep -q "name:"; then
            release_name=$(echo "$line" | awk '{print $2}')
        elif echo "$line" | grep -q "namespace:"; then
            release_namespace=$(echo "$line" | awk '{print $2}')
        elif echo "$line" | grep -q "chart:"; then
            release_chart=$(echo "$line" | awk '{print $2}')
            
            if [ -n "$release_name" ] && [ -n "$release_namespace" ] && [ -n "$release_chart" ]; then
                echo -e "${BLUE}📦 Restoring Helm release: $release_name in $release_namespace${NC}"
                
                # Check if values file exists
                values_file="${FULL_BACKUP_PATH}/helm/${release_name}-values.yaml"
                if [ -f "$values_file" ]; then
                    echo -e "${BLUE}📄 Using values file: $values_file${NC}"
                    helm install "$release_name" "$release_chart" -n "$release_namespace" -f "$values_file" --create-namespace || \
                    helm upgrade "$release_name" "$release_chart" -n "$release_namespace" -f "$values_file" || \
                    echo -e "${YELLOW}⚠️  Could not restore Helm release: $release_name${NC}"
                else
                    echo -e "${YELLOW}⚠️  No values file found for $release_name, installing with default values${NC}"
                    helm install "$release_name" "$release_chart" -n "$release_namespace" --create-namespace || \
                    echo -e "${YELLOW}⚠️  Could not restore Helm release: $release_name${NC}"
                fi
                
                # Reset variables
                release_name=""
                release_namespace=""
                release_chart=""
            fi
        fi
    done < "${FULL_BACKUP_PATH}/helm/releases.yaml"
else
    echo -e "${YELLOW}⚠️  No Helm releases backup found${NC}"
fi

# Final status check
echo -e "${GREEN}✅ Restore process completed!${NC}"
echo -e "${BLUE}📊 Checking final status...${NC}"

echo -e "${YELLOW}📋 Namespace Status:${NC}"
kubectl get namespaces

echo -e "${YELLOW}📋 Pod Status:${NC}"
kubectl get pods --all-namespaces

echo -e "${YELLOW}📋 Helm Releases:${NC}"
helm list --all-namespaces

echo -e "${GREEN}🎉 Restore completed successfully!${NC}"
echo -e "${YELLOW}💡 Note: Some pods may take time to start. Check status with: kubectl get pods --all-namespaces${NC}"
